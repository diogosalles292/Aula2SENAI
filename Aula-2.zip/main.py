numero = int(input("digite um numero"))
numero2 = int(input("digite outro numero"))
print(numero + numero2)

nome = "Diogo"
print(nome)

nome = "Diogo"
cumprimento = "Ola"
print(comprimento, nome)

numero4 = int(input("digite um numero"))
numero5 = int(input("digite outro numero"))
print(numero4* numero5)